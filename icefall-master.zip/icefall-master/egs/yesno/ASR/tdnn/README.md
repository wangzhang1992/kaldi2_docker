
## How to run this recipe

You can find detailed instructions by visiting
<https://icefall.readthedocs.io/en/latest/recipes/yesno.html>

It describes how to run this recipe and how to use
a pre-trained model with `./pretrained.py`.
