## Introduction

Files in this folder are modified from [CUDPP](https://github.com/cudpp/cudpp).

Code style in these files is different from what k2 is using.
