
# DLpack

`dlpack.h` is downloaded using

```bash
curl https://raw.githubusercontent.com/dmlc/dlpack/3efc489b55385936531a06ff83425b719387ec63/include/dlpack/dlpack.h > dlpack.h
```
