utils
=====

.. currentmodule:: k2

to_str
------

.. autofunction:: to_str

to_str_simple
-------------

.. autofunction:: to_str_simple

to_tensor
---------

.. autofunction:: to_tensor

to_dot
------

.. autofunction:: to_dot

create_fsa_vec
--------------

.. autofunction:: create_fsa_vec

is_rand_equivalent
------------------

.. autofunction:: is_rand_equivalent

create_sparse
-------------

.. autofunction:: create_sparse

random_fsa
----------

.. autofunction:: random_fsa

random_fsa_vec
--------------

.. autofunction:: random_fsa_vec
