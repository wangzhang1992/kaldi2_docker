ragged_ops
==========

.. currentmodule:: k2.ragged

index
-----

.. autofunction:: index

remove_values_leq
------------------

.. autofunction:: remove_values_leq

remove_values_eq
----------------

.. autofunction:: remove_values_eq

remove_axis
-----------

.. autofunction:: remove_axis

to_list
-------

.. autofunction:: to_list

pad
---

.. autofunction:: pad

sum_per_sublist
---------------

.. autofunction:: sum_per_sublist

cat
---

.. autofunction:: cat

create_ragged2
--------------

.. autofunction:: create_ragged2

get_layer
---------

.. autofunction:: get_layer

unique_sequences
----------------

.. autofunction:: unique_sequences

regular_ragged_shape
--------------------

.. autofunction:: regular_ragged_shape

argmax_per_sublist
------------------

.. autofunction:: argmax_per_sublist

max_per_sublist
---------------

.. autofunction:: max_per_sublist

sort_sublist
------------

.. autofunction:: sort_sublist
