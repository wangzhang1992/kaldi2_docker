ragged_shape
============

.. currentmodule:: k2.ragged

create_ragged_shape2
--------------------

.. autofunction:: create_ragged_shape2


compose_ragged_shapes
---------------------

.. autofunction:: compose_ragged_shapes
