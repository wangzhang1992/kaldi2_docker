CTC Loss
========

.. currentmodule:: k2

CtcLoss
--------

.. autoclass:: CtcLoss


ctc_loss
--------

.. autofunction:: ctc_loss
