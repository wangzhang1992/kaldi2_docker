build_type = None
git_date = None
git_sha1 = None
__version__ = None
with_cuda = None
