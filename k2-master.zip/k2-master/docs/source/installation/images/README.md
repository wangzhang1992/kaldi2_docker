
## File description

<https://shields.io/> is used to create the following files:

- python-3.6_3.7_3.8-blue.svg
- cuda-10.1_10.2_11.0_11.1-orange.svg
- pytorch-1.6.0_1.7.0_1.7.1_1.8.0_1.8.1-green.svg

- pypi_python-3.6_3.7_3.8-blue.svg
- pypi_cuda-10.1-orange.svg
- pypi_pytorch-1.7.1-green.svg

- pip_python-3.6_3.7_3.8-blue.svg
- pip_cuda-10.1_10.2_11.0-orange.svg
- pip_pytorch-1.7.1-green.svg

- source_python-3.6_3.7_3.8_3.9-blue.svg
- source_cuda-10.1_10.2_11.0_11.1-orange.svg
- source_pytorch-1.6.0_1.7.0_1.7.1_1.8.0_1.8.1-green.svg
